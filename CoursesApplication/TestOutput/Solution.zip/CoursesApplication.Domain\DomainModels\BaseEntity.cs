namespace CoursesApplication.Domain.DomainModels;

public class BaseEntity
{
    public Guid Id { get; set; }
}